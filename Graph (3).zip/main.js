var div = document.getElementById('ForGraph');
var graph = new Graph(div);

graph.addDiagram('red',[0,1,2,6,4,5,30,3,1,4,2,31,23,41,5,23,14],1,2);
graph.addDiagram('green',[11,33,14,22,5,3,2,5,11,50],1,2);
graph.addDiagram('orange',[-5,11,12,4,2,10,30,2,3,42,7,12,32,4,11,0,-3,-6,-8,1,2,3,5],1,2);
